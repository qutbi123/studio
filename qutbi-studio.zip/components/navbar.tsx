"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, ChevronDown } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import Image from "next/image"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const navigation = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Privacy Policy", href: "/privacy" },
  ]

  const aiTools = [
    { name: "All AI Tools", href: "/tools" },
    { name: "AI Image Generator", href: "/tools/image" },
    { name: "AI Chat Assistant", href: "/tools/chat" },
    { name: "AI Voice Generator", href: "/tools/voice" },
    { name: "AI Video Maker", href: "/tools/video" },
  ]

  return (
    <nav className="sticky top-0 z-50 bg-transparent backdrop-blur-md supports-[backdrop-filter]:bg-background/20 border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link href="/" className="flex items-center space-x-2">
              <div className="relative w-8 h-8">
                <Image
                  src="/images/qutbi-logo.png"
                  alt="QutbiStudio Logo"
                  width={32}
                  height={32}
                  className="dark:invert transition-all duration-200"
                />
              </div>
              <span className="text-xl font-bold text-primary">QutbiStudio</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <Link
                href="/"
                className="text-foreground hover:text-accent transition-colors duration-200 px-3 py-2 text-sm font-medium"
              >
                Home
              </Link>

              <DropdownMenu>
                <DropdownMenuTrigger className="text-foreground hover:text-accent transition-colors duration-200 px-3 py-2 text-sm font-medium flex items-center gap-1">
                  AI Tools
                  <ChevronDown className="h-4 w-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="start"
                  className="w-48 bg-background/95 backdrop-blur-sm border-2 border-accent/20 shadow-lg"
                >
                  {aiTools.map((tool) => (
                    <DropdownMenuItem key={tool.name} asChild className="hover:bg-accent/10 focus:bg-accent/10">
                      <Link href={tool.href} className="w-full text-foreground hover:text-accent">
                        {tool.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <Link
                href="/about"
                className="text-foreground hover:text-accent transition-colors duration-200 px-3 py-2 text-sm font-medium"
              >
                About
              </Link>

              <Link
                href="/privacy"
                className="text-foreground hover:text-accent transition-colors duration-200 px-3 py-2 text-sm font-medium"
              >
                Privacy Policy
              </Link>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <ThemeToggle />
            <Button asChild className="bg-accent hover:bg-accent/90">
              <Link href="/tools">Get Started</Link>
            </Button>
          </div>

          <div className="md:hidden flex items-center space-x-2">
            <ThemeToggle />
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden bg-background/95 backdrop-blur-sm border border-accent/20 rounded-lg mt-2 shadow-lg">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-border/50">
              <Link
                href="/"
                className="text-foreground hover:text-accent block px-3 py-2 text-base font-medium transition-colors duration-200"
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>

              <div className="border-t border-border/50 pt-2 mt-2">
                <div className="px-3 py-2 text-sm font-semibold text-muted-foreground">AI Tools</div>
                {aiTools.map((tool) => (
                  <Link
                    key={tool.name}
                    href={tool.href}
                    className="text-foreground hover:text-accent block px-6 py-2 text-base font-medium transition-colors duration-200"
                    onClick={() => setIsOpen(false)}
                  >
                    {tool.name}
                  </Link>
                ))}
              </div>

              <Link
                href="/about"
                className="text-foreground hover:text-accent block px-3 py-2 text-base font-medium transition-colors duration-200"
                onClick={() => setIsOpen(false)}
              >
                About
              </Link>

              <Link
                href="/privacy"
                className="text-foreground hover:text-accent block px-3 py-2 text-base font-medium transition-colors duration-200"
                onClick={() => setIsOpen(false)}
              >
                Privacy Policy
              </Link>

              <div className="pt-2">
                <Button asChild className="w-full bg-accent hover:bg-accent/90">
                  <Link href="/tools" onClick={() => setIsOpen(false)}>
                    Get Started
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
