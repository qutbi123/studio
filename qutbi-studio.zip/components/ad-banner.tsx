export function AdBanner({
  size = "horizontal",
  className = "",
}: {
  size?: "horizontal" | "vertical" | "square"
  className?: string
}) {
  const sizeClasses = {
    horizontal: "w-full h-24 md:h-32",
    vertical: "w-48 h-96",
    square: "w-64 h-64",
  }

  return (
    <div
      className={`${sizeClasses[size]} ${className} bg-gradient-to-r from-accent/10 to-accent/20 border-2 border-dashed border-accent/30 rounded-lg flex flex-col items-center justify-center text-center p-4 hover:from-accent/20 hover:to-accent/30 transition-all duration-300`}
    >
      <div className="text-accent font-semibold text-sm md:text-base mb-1">Advertisement Space</div>
      <div className="text-muted-foreground text-xs md:text-sm">Your Ad Here - 728x90</div>
      <div className="text-xs text-muted-foreground/70 mt-1">Premium Placement Available</div>
      {/* 
        AD SCRIPT PLACEMENT:
        Replace this entire div with your ad network script (Google AdSense, etc.)
        Example: <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      */}
    </div>
  )
}
