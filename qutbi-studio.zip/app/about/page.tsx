import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { SparklesIcon, TargetIcon, UsersIcon, RocketIcon, ShieldIcon, HeartIcon } from "lucide-react"
import Image from "next/image"
import { AdBanner } from "@/components/ad-banner"

export default function AboutPage() {
  const values = [
    {
      title: "Innovation",
      description: "We push the boundaries of AI technology to create tools that transform how you work and create.",
      icon: SparklesIcon,
      color: "text-emerald-600",
    },
    {
      title: "Accessibility",
      description: "Making powerful AI tools available to everyone, regardless of technical expertise or background.",
      icon: UsersIcon,
      color: "text-emerald-600",
    },
    {
      title: "Quality",
      description: "We're committed to delivering high-quality, reliable AI solutions that exceed expectations.",
      icon: TargetIcon,
      color: "text-emerald-600",
    },
    {
      title: "Growth",
      description: "Empowering individuals and businesses to grow and achieve their goals through AI assistance.",
      icon: RocketIcon,
      color: "text-emerald-600",
    },
    {
      title: "Trust",
      description: "Building secure, transparent AI tools that you can rely on for your most important projects.",
      icon: ShieldIcon,
      color: "text-emerald-600",
    },
    {
      title: "Community",
      description: "Fostering a community of creators, innovators, and dreamers who shape the future with AI.",
      icon: HeartIcon,
      color: "text-emerald-600",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl xs:text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-4 sm:mb-6 text-balance leading-tight">
            About <span className="text-accent">QutbiStudio</span>
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground text-pretty px-4 sm:px-0">
            Kashmir First AI studio - Pioneering the future of AI-powered creativity and productivity tools.
          </p>
        </div>
      </section>

      <AdBanner
        type="horizontal"
        title="Advertise Here"
        description="Premium ad placement - Contact us for rates"
        className="my-8"
      />
      {/* ADD AD SCRIPT HERE: Place your ad network script (Google AdSense, etc.) in this AdBanner component */}

      {/* Founder's Message Section */}
      <section className="py-12 sm:py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Founder's Message</h2>
          </div>

          <Card className="border-border bg-card max-w-4xl mx-auto">
            <CardContent className="p-6 sm:p-8">
              <div className="flex flex-col md:flex-row gap-6 sm:gap-8 items-center md:items-start">
                <div className="flex-shrink-0">
                  <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full overflow-hidden border-4 border-accent/20">
                    <Image
                      src="/images/founder.jpg"
                      alt="Qutbi Shahzada Muhammad Usman Ali Awan Alvi - Founder & CEO"
                      width={160}
                      height={160}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <blockquote className="text-muted-foreground leading-relaxed text-sm sm:text-base mb-6">
                    "Dear Visitors,
                    <br />
                    <br />
                    It gives me great pleasure to announce that through our company,{" "}
                    <strong>Qutbi Technologies & Innovative Solution</strong>, we have launched Kashmir First AI studio.
                    <br />
                    <br />
                    This platform is specially designed to bring you advanced AI tools all in one place — including AI
                    Chat Assistance, AI Image Generator, AI Voice Generator, and AI Video Maker.
                    <br />
                    <br />
                    Our mission is to provide you with the best experience and innovative solutions that make your
                    digital journey easier and more powerful.
                    <br />
                    <br />
                    We look forward to your valuable feedback and truly hope you will like our project."
                  </blockquote>

                  <div className="text-center md:text-left">
                    <p className="font-semibold text-primary text-lg">Qutbi Shahzada Muhammad Usman Ali Awan Alvi</p>
                    <p className="text-accent font-medium">Founder & CEO</p>
                    <p className="text-muted-foreground text-sm">Qutbi Technologies & Innovative Solution</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
            <div>
              <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">Our Mission</h2>
              <p className="text-base sm:text-lg text-muted-foreground mb-4 sm:mb-6 leading-relaxed">
                At QutbiStudio, we believe that artificial intelligence should be a force for creativity, not
                complexity. Our mission is to democratize access to powerful AI tools, making them intuitive,
                accessible, and transformative for creators, professionals, and innovators worldwide.
              </p>
              <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                We're building a future where AI amplifies human potential, enabling you to focus on what matters most:
                bringing your ideas to life, solving complex problems, and creating meaningful impact in your field.
              </p>
            </div>
            <div className="bg-muted/50 rounded-2xl p-6 sm:p-8 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-accent/10 rounded-full mb-4 sm:mb-6">
                <SparklesIcon className="h-8 w-8 sm:h-10 sm:w-10 text-accent" />
              </div>
              <h3 className="text-xl sm:text-2xl font-semibold text-primary mb-3 sm:mb-4">Empowering Creativity</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                Every tool we create is designed to enhance your natural creativity and help you achieve results that
                were once impossible.
              </p>
            </div>
          </div>
        </div>
      </section>

      <AdBanner type="square" title="Your Ad Here" description="High-visibility placement" className="my-8" />
      {/* ADD AD SCRIPT HERE: Place your ad network script for square/banner ads here */}

      {/* Values Section */}
      <section className="py-12 sm:py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Our Values</h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto px-4 sm:px-0">
              The principles that guide everything we do at QutbiStudio.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {values.map((value) => {
              const IconComponent = value.icon
              return (
                <Card
                  key={value.title}
                  className="group hover:shadow-lg transition-all duration-300 border-border bg-card"
                >
                  <CardHeader className="text-center pb-3 sm:pb-4 p-4 sm:p-6">
                    <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-muted mb-3 sm:mb-4 mx-auto group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className={`h-6 w-6 sm:h-8 sm:w-8 ${value.color}`} />
                    </div>
                    <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground">
                      {value.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <CardDescription className="text-muted-foreground text-center leading-relaxed text-sm sm:text-base">
                      {value.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">Our Story</h2>
          </div>

          <div className="space-y-6 sm:space-y-8">
            <Card className="border-border bg-card">
              <CardContent className="p-6 sm:p-8">
                <h3 className="text-xl sm:text-2xl font-semibold text-card-foreground mb-3 sm:mb-4">The Beginning</h3>
                <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">
                  QutbiStudio was born from a simple observation: while AI technology was advancing rapidly, the tools
                  available to everyday users were either too complex, too expensive, or too limited. We saw an
                  opportunity to bridge this gap and make powerful AI accessible to everyone.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="p-6 sm:p-8">
                <h3 className="text-xl sm:text-2xl font-semibold text-card-foreground mb-3 sm:mb-4">Today</h3>
                <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">
                  Today, QutbiStudio offers a comprehensive suite of AI tools that span image generation, voice
                  synthesis, intelligent chat assistance, and video creation. Our platform serves thousands of users
                  worldwide, from individual creators to large enterprises, all united by the desire to harness AI for
                  positive impact.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="p-6 sm:p-8">
                <h3 className="text-xl sm:text-2xl font-semibold text-card-foreground mb-3 sm:mb-4">The Future</h3>
                <p className="text-muted-foreground leading-relaxed text-sm sm:text-base">
                  We're just getting started. Our roadmap includes expanding our AI capabilities, improving user
                  experience, and developing new tools that push the boundaries of what's possible. We're committed to
                  staying at the forefront of AI innovation while maintaining our core values of accessibility, quality,
                  and user empowerment.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <AdBanner
        type="horizontal"
        title="Partner With Us"
        description="Reach our engaged AI community"
        className="my-8"
      />
      {/* ADD AD SCRIPT HERE: Place your footer ad script here for maximum visibility */}

      <Footer />
    </div>
  )
}
