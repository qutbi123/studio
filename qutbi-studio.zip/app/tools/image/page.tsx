"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AdBanner } from "@/components/ad-banner"
import { ImageIcon, ArrowLeftIcon, SparklesIcon, PaletteIcon, ZapIcon, DownloadIcon, LoaderIcon } from "lucide-react"

export default function ImageGeneratorPage() {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("photorealistic")
  const [size, setSize] = useState("1024x1024")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const generateImage = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt")
      return
    }

    setIsGenerating(true)
    setError(null)
    setGeneratedImage(null)

    try {
      // Using Pollinations.ai API - no API key needed
      const encodedPrompt = encodeURIComponent(`${prompt}, ${style} style`)
      const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${size.split("x")[0]}&height=${size.split("x")[1]}&seed=${Math.floor(Math.random() * 1000000)}`

      // Pre-load the image to ensure it's generated
      const img = new Image()
      img.crossOrigin = "anonymous"
      img.onload = () => {
        setGeneratedImage(imageUrl)
        setIsGenerating(false)
      }
      img.onerror = () => {
        setError("Failed to generate image. Please try again.")
        setIsGenerating(false)
      }
      img.src = imageUrl
    } catch (err) {
      setError("An error occurred while generating the image")
      setIsGenerating(false)
    }
  }

  const downloadImage = async () => {
    if (!generatedImage) return

    try {
      const response = await fetch(generatedImage)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `qutbi-ai-image-${Date.now()}.png`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (err) {
      setError("Failed to download image")
    }
  }

  const features = [
    {
      icon: PaletteIcon,
      title: "Multiple Art Styles",
      description: "Choose from photorealistic, artistic, cartoon, and abstract styles",
    },
    {
      icon: ZapIcon,
      title: "Lightning Fast",
      description: "Generate high-quality images in seconds with our optimized AI models",
    },
    {
      icon: DownloadIcon,
      title: "High Resolution",
      description: "Download images in various resolutions up to 4K quality",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-blue-50 dark:bg-blue-950 rounded-full mb-6 sm:mb-8">
            <ImageIcon className="h-8 w-8 sm:h-10 sm:w-10 text-blue-600" />
          </div>
          <h1 className="text-3xl xs:text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-4 sm:mb-6 text-balance leading-tight">
            AI Image <span className="text-accent">Generator</span>
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground text-pretty max-w-xs xs:max-w-sm sm:max-w-3xl mx-auto mb-6 sm:mb-8 px-4 sm:px-0">
            Transform your ideas into stunning visuals with our advanced AI image generation technology.
          </p>

          <div className="inline-flex items-center gap-2 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 px-4 sm:px-6 py-2 sm:py-3 rounded-full text-base sm:text-lg font-medium">
            <SparklesIcon className="h-4 w-4 sm:h-5 sm:w-5" />
            Generate Now - Free!
          </div>
        </div>
      </section>

      <AdBanner
        type="horizontal"
        title="Advertise Here"
        description="Reach creative professionals and AI enthusiasts"
        className="my-8"
      />
      {/* ADD AD SCRIPT HERE: Place your ad network script for top banner placement */}

      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Create Your Image</h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Describe what you want to see and watch AI bring it to life
            </p>
          </div>

          <Card className="mb-6 sm:mb-8">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle className="text-lg sm:text-xl">Image Generator</CardTitle>
              <CardDescription className="text-sm sm:text-base">
                Enter your prompt and customize the settings below
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6 p-4 sm:p-6 pt-0">
              <div className="space-y-2">
                <Label htmlFor="prompt" className="text-sm sm:text-base">
                  Prompt
                </Label>
                <Textarea
                  id="prompt"
                  placeholder="Describe the image you want to generate... (e.g., 'A majestic mountain landscape at sunset with a lake reflection')"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={3}
                  className="text-sm sm:text-base"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="style" className="text-sm sm:text-base">
                    Style
                  </Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger className="text-sm sm:text-base">
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="photorealistic">Photorealistic</SelectItem>
                      <SelectItem value="artistic">Artistic</SelectItem>
                      <SelectItem value="cartoon">Cartoon</SelectItem>
                      <SelectItem value="abstract">Abstract</SelectItem>
                      <SelectItem value="oil painting">Oil Painting</SelectItem>
                      <SelectItem value="watercolor">Watercolor</SelectItem>
                      <SelectItem value="digital art">Digital Art</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="size" className="text-sm sm:text-base">
                    Size
                  </Label>
                  <Select value={size} onValueChange={setSize}>
                    <SelectTrigger className="text-sm sm:text-base">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="512x512">512x512 (Square)</SelectItem>
                      <SelectItem value="1024x1024">1024x1024 (Square HD)</SelectItem>
                      <SelectItem value="1024x768">1024x768 (Landscape)</SelectItem>
                      <SelectItem value="768x1024">768x1024 (Portrait)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {error && (
                <div className="p-3 sm:p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300 text-sm sm:text-base">
                  {error}
                </div>
              )}

              <Button
                onClick={generateImage}
                disabled={isGenerating || !prompt.trim()}
                className="w-full bg-accent hover:bg-accent/90 text-sm sm:text-base"
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <SparklesIcon className="h-4 w-4 mr-2" />
                    Generate Image
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Generated Image Display */}
          {generatedImage && (
            <Card>
              <CardHeader className="p-4 sm:p-6">
                <CardTitle className="text-lg sm:text-xl">Generated Image</CardTitle>
                <CardDescription className="text-sm sm:text-base">Your AI-generated image is ready!</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0">
                <div className="space-y-4">
                  <div className="relative">
                    <img
                      src={generatedImage || "/placeholder.svg"}
                      alt="Generated AI image"
                      className="w-full rounded-lg shadow-lg"
                    />
                  </div>
                  <div className="flex flex-col xs:flex-row gap-2">
                    <Button onClick={downloadImage} className="flex-1 text-sm sm:text-base">
                      <DownloadIcon className="h-4 w-4 mr-2" />
                      Download Image
                    </Button>
                    <Button
                      onClick={() => setGeneratedImage(null)}
                      variant="outline"
                      className="flex-1 text-sm sm:text-base"
                    >
                      Generate New
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <AdBanner
            type="square"
            title="Your Ad Here"
            description="Target users actively creating content"
            className="my-8"
          />
          {/* ADD AD SCRIPT HERE: Place your ad script for engaged users who just generated images */}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Powerful Features</h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Everything you need to create amazing images with AI
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
            {features.map((feature) => {
              const IconComponent = feature.icon
              return (
                <Card key={feature.title} className="text-center border-border bg-card">
                  <CardHeader className="p-4 sm:p-6">
                    <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-muted rounded-lg mb-3 sm:mb-4 mx-auto">
                      <IconComponent className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                    </div>
                    <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <CardDescription className="text-muted-foreground text-sm sm:text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">Ready to Create?</h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto px-4 sm:px-0">
            Start generating stunning AI images right now. No sign-up required, completely free to use.
          </p>
          <div className="flex flex-col xs:flex-row gap-3 sm:gap-4 justify-center px-4 sm:px-0">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 w-full xs:w-auto text-sm sm:text-base">
              <Link href="/tools" className="flex items-center justify-center gap-2">
                <ArrowLeftIcon className="h-4 w-4" />
                Explore Other Tools
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="bg-transparent w-full xs:w-auto text-sm sm:text-base"
            >
              <Link href="/about">Learn More About QutbiStudio</Link>
            </Button>
          </div>
        </div>
      </section>

      <AdBanner
        type="horizontal"
        title="Premium Ad Space"
        description="Bottom placement for maximum visibility"
        className="my-8"
      />
      {/* ADD AD SCRIPT HERE: Place your bottom banner ad script here */}

      <Footer />
    </div>
  )
}
