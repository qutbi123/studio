"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import {
  VideoIcon,
  ArrowLeftIcon,
  SparklesIcon,
  EditIcon,
  PlayIcon,
  SettingsIcon,
  LoaderIcon,
  DownloadIcon,
} from "lucide-react"

export default function VideoMakerPage() {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("cinematic")
  const [duration, setDuration] = useState([3])
  const [fps, setFps] = useState("24")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedFrames, setGeneratedFrames] = useState<string[]>([])
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [currentStep, setCurrentStep] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  const generateVideo = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt for your video")
      return
    }

    setIsGenerating(true)
    setError(null)
    setGeneratedFrames([])
    setVideoBlob(null)
    setCurrentStep("Generating frames...")

    try {
      const frameCount = duration[0] * Number.parseInt(fps)
      const frames: string[] = []

      // Generate multiple frames for the video
      for (let i = 0; i < Math.min(frameCount, 30); i++) {
        setCurrentStep(`Generating frame ${i + 1} of ${Math.min(frameCount, 30)}...`)

        // Create variations of the prompt for different frames
        const framePrompt = `${prompt}, ${style} style, frame ${i + 1}, cinematic sequence`
        const encodedPrompt = encodeURIComponent(framePrompt)
        const seed = Math.floor(Math.random() * 1000000) + i * 1000

        const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=576&seed=${seed}`

        // Pre-load each frame
        await new Promise<void>((resolve, reject) => {
          const img = new Image()
          img.crossOrigin = "anonymous"
          img.onload = () => {
            frames.push(imageUrl)
            resolve()
          }
          img.onerror = () => reject(new Error(`Failed to generate frame ${i + 1}`))
          img.src = imageUrl
        })

        // Small delay between frames to avoid rate limiting
        await new Promise((resolve) => setTimeout(resolve, 500))
      }

      setGeneratedFrames(frames)
      setCurrentStep("Creating video from frames...")

      // Create video from frames using Canvas and MediaRecorder
      await createVideoFromFrames(frames)

      setCurrentStep("Video ready!")
      setIsGenerating(false)
    } catch (err) {
      console.error("Video generation error:", err)
      setError("Failed to generate video. Please try again with a different prompt.")
      setIsGenerating(false)
      setCurrentStep("")
    }
  }

  const createVideoFromFrames = async (frames: string[]): Promise<void> => {
    return new Promise((resolve, reject) => {
      const canvas = canvasRef.current
      if (!canvas) {
        reject(new Error("Canvas not available"))
        return
      }

      const ctx = canvas.getContext("2d")
      if (!ctx) {
        reject(new Error("Canvas context not available"))
        return
      }

      canvas.width = 1024
      canvas.height = 576

      // Create MediaRecorder to capture canvas
      const stream = canvas.captureStream(Number.parseInt(fps))
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: "video/webm;codecs=vp9",
      })

      const chunks: Blob[] = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" })
        setVideoBlob(blob)
        resolve()
      }

      mediaRecorder.onerror = (event) => {
        reject(new Error("MediaRecorder error"))
      }

      // Start recording
      mediaRecorder.start()

      let frameIndex = 0
      const frameDuration = 1000 / Number.parseInt(fps) // milliseconds per frame

      const drawFrame = () => {
        if (frameIndex >= frames.length) {
          mediaRecorder.stop()
          return
        }

        const img = new Image()
        img.crossOrigin = "anonymous"
        img.onload = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height)
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
          frameIndex++
          setTimeout(drawFrame, frameDuration)
        }
        img.src = frames[frameIndex]
      }

      drawFrame()
    })
  }

  const downloadVideo = () => {
    if (!videoBlob) {
      setError("No video available for download. Please generate a video first.")
      return
    }

    const url = URL.createObjectURL(videoBlob)
    const a = document.createElement("a")
    a.href = url
    a.download = `qutbi-ai-video-${Date.now()}.webm`
    document.body.appendChild(a)
    a.click()
    URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  const features = [
    {
      icon: EditIcon,
      title: "Auto Editing",
      description: "Intelligent video editing with scene detection and transitions",
    },
    {
      icon: PlayIcon,
      title: "Multiple Formats",
      description: "Export in various resolutions and formats for any platform",
    },
    {
      icon: SettingsIcon,
      title: "Custom Controls",
      description: "Fine-tune every aspect of your video generation process",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-red-50 rounded-full mb-8">
            <VideoIcon className="h-10 w-10 text-red-600" />
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-6 text-balance">
            AI Video <span className="text-accent">Maker</span>
          </h1>
          <p className="text-xl sm:text-2xl text-muted-foreground text-pretty max-w-3xl mx-auto mb-8">
            Create and edit professional videos with the power of artificial intelligence.
          </p>

          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-6 py-3 rounded-full text-lg font-medium">
            <SparklesIcon className="h-5 w-5" />
            Create Videos - Free!
          </div>
        </div>
      </section>

      {/* Video Generator Interface */}
      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4">Create Your Video</h2>
            <p className="text-xl text-muted-foreground">Describe your vision and watch AI bring it to life</p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Video Generator</CardTitle>
              <CardDescription>Generate videos from text descriptions using AI</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="prompt">Video Description</Label>
                <Textarea
                  id="prompt"
                  placeholder="Describe the video you want to create... (e.g., 'A serene sunset over a mountain lake with gentle waves')"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="style">Style</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cinematic">Cinematic</SelectItem>
                      <SelectItem value="documentary">Documentary</SelectItem>
                      <SelectItem value="artistic">Artistic</SelectItem>
                      <SelectItem value="realistic">Realistic</SelectItem>
                      <SelectItem value="animated">Animated</SelectItem>
                      <SelectItem value="vintage">Vintage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Duration: {duration[0]}s</Label>
                  <Slider value={duration} onValueChange={setDuration} min={1} max={10} step={1} className="w-full" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fps">Frame Rate</Label>
                  <Select value={fps} onValueChange={setFps}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select FPS" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="12">12 FPS</SelectItem>
                      <SelectItem value="24">24 FPS</SelectItem>
                      <SelectItem value="30">30 FPS</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {error && <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>}

              {currentStep && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-blue-700">
                  <div className="flex items-center gap-2">
                    <LoaderIcon className="h-4 w-4 animate-spin" />
                    {currentStep}
                  </div>
                </div>
              )}

              <Button
                onClick={generateVideo}
                disabled={isGenerating || !prompt.trim()}
                className="w-full bg-accent hover:bg-accent/90"
                size="lg"
              >
                {isGenerating ? (
                  <>
                    <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                    Generating Video...
                  </>
                ) : (
                  <>
                    <VideoIcon className="h-4 w-4 mr-2" />
                    Generate Video
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Generated Frames Preview */}
          {generatedFrames.length > 0 && (
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Generated Frames</CardTitle>
                <CardDescription>Preview of the frames that will be used in your video</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  {generatedFrames.slice(0, 8).map((frame, index) => (
                    <div key={index} className="relative">
                      <img
                        src={frame || "/placeholder.svg"}
                        alt={`Frame ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg"
                      />
                      <div className="absolute bottom-1 left-1 bg-black/70 text-white text-xs px-1 rounded">
                        {index + 1}
                      </div>
                    </div>
                  ))}
                </div>
                {generatedFrames.length > 8 && (
                  <p className="text-sm text-muted-foreground">+{generatedFrames.length - 8} more frames...</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Generated Video Display */}
          {videoBlob && (
            <Card>
              <CardHeader>
                <CardTitle>Generated Video</CardTitle>
                <CardDescription>Your AI-generated video is ready!</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <video
                    ref={videoRef}
                    controls
                    className="w-full rounded-lg shadow-lg"
                    src={videoBlob ? URL.createObjectURL(videoBlob) : undefined}
                  />
                  <div className="flex gap-2">
                    <Button onClick={downloadVideo} className="flex-1">
                      <DownloadIcon className="h-4 w-4 mr-2" />
                      Download Video
                    </Button>
                    <Button onClick={() => setVideoBlob(null)} variant="outline" className="flex-1">
                      Generate New
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Hidden canvas for video generation */}
          <canvas ref={canvasRef} style={{ display: "none" }} />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4">Professional Video Features</h2>
            <p className="text-xl text-muted-foreground">Everything you need to create stunning videos with AI</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature) => {
              const IconComponent = feature.icon
              return (
                <Card key={feature.title} className="text-center border-border bg-card">
                  <CardHeader>
                    <div className="inline-flex items-center justify-center w-12 h-12 bg-muted rounded-lg mb-4 mx-auto">
                      <IconComponent className="h-6 w-6 text-accent" />
                    </div>
                    <CardTitle className="text-xl font-semibold text-card-foreground">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-muted-foreground">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-6">Start Creating Videos</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Transform your ideas into professional videos with AI-generated frames and automatic video compilation. No
            registration required, completely free to use.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90">
              <Link href="/tools" className="flex items-center gap-2">
                <ArrowLeftIcon className="h-4 w-4" />
                Explore Other Tools
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="bg-transparent">
              <Link href="/about">Learn More About QutbiStudio</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
