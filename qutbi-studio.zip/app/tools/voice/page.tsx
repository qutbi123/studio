"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import {
  MicIcon,
  ArrowLeftIcon,
  SparklesIcon,
  LanguagesIcon,
  VolumeXIcon,
  FileAudioIcon,
  PlayIcon,
  PauseIcon,
  StampIcon as StopIcon,
  DownloadIcon,
  LoaderIcon,
} from "lucide-react"

export default function VoiceGeneratorPage() {
  const [text, setText] = useState("")
  const [selectedVoice, setSelectedVoice] = useState("")
  const [rate, setRate] = useState([1])
  const [pitch, setPitch] = useState([1])
  const [volume, setVolume] = useState([1])
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentUtterance, setCurrentUtterance] = useState<SpeechSynthesisUtterance | null>(null)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = speechSynthesis.getVoices()
      setVoices(availableVoices)
      if (availableVoices.length > 0 && !selectedVoice) {
        setSelectedVoice(availableVoices[0].name)
      }
    }

    loadVoices()
    speechSynthesis.addEventListener("voiceschanged", loadVoices)

    return () => {
      speechSynthesis.removeEventListener("voiceschanged", loadVoices)
    }
  }, [selectedVoice])

  const generateSpeech = async () => {
    if (!text.trim()) {
      setError("Please enter some text to convert to speech")
      return
    }

    setError(null)
    setIsGenerating(true)

    try {
      // Stop any current speech
      speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      const voice = voices.find((v) => v.name === selectedVoice)

      if (voice) {
        utterance.voice = voice
      }

      utterance.rate = rate[0]
      utterance.pitch = pitch[0]
      utterance.volume = volume[0]

      utterance.onstart = () => {
        setIsPlaying(true)
        setIsPaused(false)
        setIsGenerating(false)
      }

      utterance.onend = () => {
        setIsPlaying(false)
        setIsPaused(false)
      }

      utterance.onerror = (event) => {
        setError(`Speech synthesis error: ${event.error}`)
        setIsPlaying(false)
        setIsPaused(false)
        setIsGenerating(false)
      }

      setCurrentUtterance(utterance)
      speechSynthesis.speak(utterance)

      // Generate audio blob for download (using MediaRecorder if available)
      try {
        await generateAudioBlob(utterance)
      } catch (err) {
        console.log("Audio blob generation not supported in this browser")
      }
    } catch (err) {
      setError("Failed to generate speech. Please try again.")
      setIsGenerating(false)
    }
  }

  const generateAudioBlob = async (utterance: SpeechSynthesisUtterance): Promise<void> => {
    return new Promise((resolve, reject) => {
      try {
        // Create a temporary audio context for recording
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
        const destination = audioContext.createMediaStreamDestination()
        const mediaRecorder = new MediaRecorder(destination.stream)
        const chunks: Blob[] = []

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            chunks.push(event.data)
          }
        }

        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: "audio/wav" })
          setAudioBlob(blob)
          resolve()
        }

        mediaRecorder.start()

        // Stop recording when speech ends
        utterance.addEventListener("end", () => {
          mediaRecorder.stop()
          audioContext.close()
        })
      } catch (err) {
        reject(err)
      }
    })
  }

  const pauseSpeech = () => {
    if (speechSynthesis.speaking && !speechSynthesis.paused) {
      speechSynthesis.pause()
      setIsPaused(true)
    }
  }

  const resumeSpeech = () => {
    if (speechSynthesis.paused) {
      speechSynthesis.resume()
      setIsPaused(false)
    }
  }

  const stopSpeech = () => {
    speechSynthesis.cancel()
    setIsPlaying(false)
    setIsPaused(false)
  }

  const downloadAudio = () => {
    if (!audioBlob) {
      setError("No audio available for download. Please generate speech first.")
      return
    }

    const url = URL.createObjectURL(audioBlob)
    const a = document.createElement("a")
    a.href = url
    a.download = `qutbi-voice-${Date.now()}.wav`
    document.body.appendChild(a)
    a.click()
    URL.revokeObjectURL(url)
    document.body.removeChild(a)
  }

  const features = [
    {
      icon: LanguagesIcon,
      title: "Multiple Languages",
      description: "Support for 50+ languages and regional accents",
    },
    {
      icon: VolumeXIcon,
      title: "Natural Voices",
      description: "Realistic human-like speech with emotional expression",
    },
    {
      icon: FileAudioIcon,
      title: "Audio Export",
      description: "Download in various formats including MP3, WAV, and more",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-50 rounded-full mb-8">
            <MicIcon className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-6 text-balance">
            AI Voice <span className="text-accent">Generator</span>
          </h1>
          <p className="text-xl sm:text-2xl text-muted-foreground text-pretty max-w-3xl mx-auto mb-8">
            Convert any text into natural-sounding speech with our advanced voice synthesis technology.
          </p>

          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-6 py-3 rounded-full text-lg font-medium">
            <SparklesIcon className="h-5 w-5" />
            Generate Voice - Free!
          </div>
        </div>
      </section>

      {/* Voice Generator Interface */}
      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4">Text to Speech</h2>
            <p className="text-xl text-muted-foreground">Enter your text and customize the voice settings</p>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Voice Generator</CardTitle>
              <CardDescription>Convert text to natural-sounding speech</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="text">Text to Convert</Label>
                <Textarea
                  id="text"
                  placeholder="Enter the text you want to convert to speech..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="voice">Voice</Label>
                  <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select voice" />
                    </SelectTrigger>
                    <SelectContent>
                      {voices.map((voice) => (
                        <SelectItem key={voice.name} value={voice.name}>
                          {voice.name} ({voice.lang})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Speed: {rate[0].toFixed(1)}x</Label>
                  <Slider value={rate} onValueChange={setRate} min={0.1} max={2} step={0.1} className="w-full" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Pitch: {pitch[0].toFixed(1)}</Label>
                  <Slider value={pitch} onValueChange={setPitch} min={0} max={2} step={0.1} className="w-full" />
                </div>

                <div className="space-y-2">
                  <Label>Volume: {Math.round(volume[0] * 100)}%</Label>
                  <Slider value={volume} onValueChange={setVolume} min={0} max={1} step={0.1} className="w-full" />
                </div>
              </div>

              {error && <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>}

              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={generateSpeech}
                  disabled={isGenerating || !text.trim()}
                  className="bg-accent hover:bg-accent/90"
                >
                  {isGenerating ? (
                    <>
                      <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <PlayIcon className="h-4 w-4 mr-2" />
                      Generate & Play
                    </>
                  )}
                </Button>

                {isPlaying && !isPaused && (
                  <Button onClick={pauseSpeech} variant="outline">
                    <PauseIcon className="h-4 w-4 mr-2" />
                    Pause
                  </Button>
                )}

                {isPaused && (
                  <Button onClick={resumeSpeech} variant="outline">
                    <PlayIcon className="h-4 w-4 mr-2" />
                    Resume
                  </Button>
                )}

                {(isPlaying || isPaused) && (
                  <Button onClick={stopSpeech} variant="outline">
                    <StopIcon className="h-4 w-4 mr-2" />
                    Stop
                  </Button>
                )}

                {audioBlob && (
                  <Button onClick={downloadAudio} variant="outline">
                    <DownloadIcon className="h-4 w-4 mr-2" />
                    Download Audio
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-4">Advanced Voice Features</h2>
            <p className="text-xl text-muted-foreground">Professional-grade text-to-speech capabilities</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature) => {
              const IconComponent = feature.icon
              return (
                <Card key={feature.title} className="text-center border-border bg-card">
                  <CardHeader>
                    <div className="inline-flex items-center justify-center w-12 h-12 bg-muted rounded-lg mb-4 mx-auto">
                      <IconComponent className="h-6 w-6 text-accent" />
                    </div>
                    <CardTitle className="text-xl font-semibold text-card-foreground">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-muted-foreground">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-primary mb-6">Start Creating Voices</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Transform any text into natural speech with customizable voices, speed, and pitch. No registration required,
            completely free to use.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90">
              <Link href="/tools" className="flex items-center gap-2">
                <ArrowLeftIcon className="h-4 w-4" />
                Explore Other Tools
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="bg-transparent">
              <Link href="/about">Learn More About QutbiStudio</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
