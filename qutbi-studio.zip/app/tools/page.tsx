import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AdBanner } from "@/components/ad-banner"
import {
  ImageIcon,
  MicIcon,
  MessageSquareIcon,
  VideoIcon,
  ArrowRightIcon,
  SparklesIcon,
  BookOpenIcon,
  TrendingUpIcon,
  UsersIcon,
  ZapIcon,
  ShieldIcon,
  GlobeIcon,
} from "lucide-react"

export default function AIToolsPage() {
  const aiTools = [
    {
      title: "AI Image Generator",
      description:
        "Create stunning, high-quality images from text descriptions using advanced AI models. Perfect for artwork, designs, and creative projects.",
      icon: ImageIcon,
      href: "/tools/image",
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950",
      features: ["Text-to-image generation", "Multiple art styles", "High resolution output", "Commercial use rights"],
    },
    {
      title: "AI Voice Generator",
      description:
        "Transform any text into natural-sounding speech with our advanced voice synthesis technology. Choose from multiple voices and languages.",
      icon: MicIcon,
      href: "/tools/voice",
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950",
      features: ["Natural voice synthesis", "Multiple languages", "Custom voice tones", "Audio file export"],
    },
    {
      title: "AI Chat Assistance",
      description:
        "Get intelligent responses and have meaningful conversations with our advanced AI assistant. Perfect for brainstorming and problem-solving.",
      icon: MessageSquareIcon,
      href: "/tools/chat",
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950",
      features: ["Intelligent conversations", "Context awareness", "Multiple topics", "Real-time responses"],
    },
    {
      title: "AI Video Maker",
      description:
        "Generate and edit videos with AI assistance. Create engaging content from scripts, images, or simple descriptions with ease.",
      icon: VideoIcon,
      href: "/tools/video",
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-950",
      features: ["Video generation", "Script-to-video", "Auto editing", "Multiple formats"],
    },
  ]

  const stats = [
    { number: "10M+", label: "Images Generated", icon: ImageIcon },
    { number: "5M+", label: "Voice Clips Created", icon: MicIcon },
    { number: "2M+", label: "Conversations", icon: MessageSquareIcon },
    { number: "500K+", label: "Videos Produced", icon: VideoIcon },
  ]

  const useCases = [
    {
      title: "Content Creation",
      description:
        "Bloggers, YouTubers, and social media creators use our tools to produce engaging visual and audio content at scale.",
      icon: TrendingUpIcon,
      examples: ["Social media posts", "YouTube thumbnails", "Podcast intros", "Blog illustrations"],
    },
    {
      title: "Business & Marketing",
      description:
        "Companies leverage our AI tools for marketing campaigns, product presentations, and customer engagement.",
      icon: UsersIcon,
      examples: ["Marketing materials", "Product demos", "Customer support", "Brand assets"],
    },
    {
      title: "Education & Training",
      description:
        "Educators and trainers create interactive learning materials, presentations, and educational content.",
      icon: BookOpenIcon,
      examples: ["Course materials", "Training videos", "Interactive lessons", "Educational graphics"],
    },
    {
      title: "Creative Projects",
      description:
        "Artists, designers, and creative professionals use our tools to explore new ideas and bring concepts to life.",
      icon: SparklesIcon,
      examples: ["Digital art", "Concept designs", "Creative writing", "Artistic exploration"],
    },
  ]

  const benefits = [
    {
      title: "Lightning Fast",
      description: "Generate content in seconds, not hours. Our optimized AI models deliver results instantly.",
      icon: ZapIcon,
    },
    {
      title: "Privacy First",
      description: "Your data stays secure. We don't store your prompts or generated content permanently.",
      icon: ShieldIcon,
    },
    {
      title: "Global Access",
      description: "Available worldwide with multi-language support and localized features.",
      icon: GlobeIcon,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-accent/20 text-accent-foreground px-3 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-medium mb-6 sm:mb-8">
            <SparklesIcon className="h-3 w-3 sm:h-4 sm:w-4" />
            Powered by Advanced AI Technology
          </div>
          <h1 className="text-3xl xs:text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-4 sm:mb-6 text-balance leading-tight">
            AI Tools for <span className="text-accent">Every Creator</span>
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground text-pretty max-w-xs xs:max-w-sm sm:max-w-3xl mx-auto px-4 sm:px-0">
            Discover our comprehensive suite of AI-powered tools designed to enhance your creativity and boost your
            productivity.
          </p>
        </div>
      </section>

      <section className="py-4 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AdBanner size="horizontal" className="mx-auto" />
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">
              Trusted by Millions
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Join the growing community of creators using QutbiStudio
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon
              return (
                <Card key={index} className="text-center border-border bg-card">
                  <CardContent className="p-4 sm:p-6">
                    <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-lg mb-3 sm:mb-4">
                      <IconComponent className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                    </div>
                    <div className="text-2xl sm:text-3xl font-bold text-primary mb-1 sm:mb-2">{stat.number}</div>
                    <div className="text-sm sm:text-base text-muted-foreground">{stat.label}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* AI Tools Grid */}
      <section className="py-16 sm:py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Our AI Tools</h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Professional-grade AI tools that work seamlessly together
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            {aiTools.map((tool) => {
              const IconComponent = tool.icon
              return (
                <Card
                  key={tool.title}
                  className="group hover:shadow-xl transition-all duration-500 hover:-translate-y-2 border-border bg-card overflow-hidden"
                >
                  <CardHeader className="pb-4 sm:pb-6 p-4 sm:p-6">
                    <div className="flex items-start gap-3 sm:gap-4">
                      <div
                        className={`flex-shrink-0 w-12 h-12 sm:w-16 sm:h-16 rounded-xl ${tool.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
                      >
                        <IconComponent className={`h-6 w-6 sm:h-8 sm:w-8 ${tool.color}`} />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg sm:text-2xl font-bold text-card-foreground mb-2 group-hover:text-accent transition-colors">
                          {tool.title}
                        </CardTitle>
                        <CardDescription className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                          {tool.description}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="pt-0 p-4 sm:p-6">
                    <div className="mb-4 sm:mb-6">
                      <h4 className="text-xs sm:text-sm font-semibold text-card-foreground mb-2 sm:mb-3 uppercase tracking-wide">
                        Key Features
                      </h4>
                      <ul className="grid grid-cols-1 xs:grid-cols-2 gap-1 sm:gap-2">
                        {tool.features.map((feature, index) => (
                          <li key={index} className="flex items-center text-xs sm:text-sm text-muted-foreground">
                            <div className="w-1.5 h-1.5 bg-accent rounded-full mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button
                      asChild
                      className="w-full bg-accent hover:bg-accent/90 group-hover:shadow-lg transition-all duration-300 text-sm sm:text-base"
                      size="lg"
                    >
                      <Link href={tool.href} className="flex items-center justify-center gap-2">
                        Try {tool.title}
                        <ArrowRightIcon className="h-3 w-3 sm:h-4 sm:w-4 group-hover:translate-x-1 transition-transform" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-12 sm:mt-16">
            <AdBanner size="horizontal" className="mx-auto" />
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">
              How People Use QutbiStudio
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-xs xs:max-w-sm sm:max-w-3xl mx-auto px-4 sm:px-0">
              Discover the endless possibilities with our AI tools across different industries and use cases
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
            {useCases.map((useCase, index) => {
              const IconComponent = useCase.icon
              return (
                <Card key={index} className="border-border bg-card">
                  <CardHeader className="p-4 sm:p-6">
                    <div className="flex items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <IconComponent className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
                      </div>
                      <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground">
                        {useCase.title}
                      </CardTitle>
                    </div>
                    <CardDescription className="text-muted-foreground text-sm sm:text-base leading-relaxed mb-4">
                      {useCase.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <div className="grid grid-cols-2 gap-2">
                      {useCase.examples.map((example, idx) => (
                        <div key={idx} className="flex items-center text-xs sm:text-sm text-muted-foreground">
                          <div className="w-1 h-1 bg-accent rounded-full mr-2 flex-shrink-0" />
                          {example}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 sm:py-24 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">
              Why Choose QutbiStudio?
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Built with creators in mind, designed for professional results
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon
              return (
                <Card key={index} className="text-center border-border bg-card">
                  <CardHeader className="p-4 sm:p-6">
                    <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 bg-accent/10 rounded-full mb-3 sm:mb-4">
                      <IconComponent className="h-6 w-6 sm:h-8 sm:w-8 text-accent" />
                    </div>
                    <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground mb-2 sm:mb-3">
                      {benefit.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <CardDescription className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                      {benefit.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto px-4 sm:px-0">
            Choose any tool above to begin creating with AI. No setup required – start generating amazing content in
            seconds.
          </p>
          <div className="flex flex-col xs:flex-row gap-3 sm:gap-4 justify-center px-4 sm:px-0">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 w-full xs:w-auto text-sm sm:text-base">
              <Link href="/tools/image" className="flex items-center justify-center gap-2">
                Start with Image Generator
                <ArrowRightIcon className="h-3 w-3 sm:h-4 sm:w-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="bg-transparent w-full xs:w-auto text-sm sm:text-base"
            >
              <Link href="/about">Learn More About QutbiStudio</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
