"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import {
  MessageSquareIcon,
  ArrowLeftIcon,
  SparklesIcon,
  BrainIcon,
  ClockIcon,
  ShieldIcon,
  SendIcon,
  UserIcon,
  BotIcon,
  LoaderIcon,
} from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export default function ChatAssistancePage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm your AI assistant powered by Hugging Face. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [selectedModel, setSelectedModel] = useState("microsoft/DialoGPT-medium")
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const huggingFaceModels = [
    { value: "microsoft/DialoGPT-medium", label: "DialoGPT Medium (Conversational)" },
    { value: "facebook/blenderbot-400M-distill", label: "BlenderBot 400M (General Chat)" },
    { value: "microsoft/DialoGPT-small", label: "DialoGPT Small (Fast Response)" },
    { value: "facebook/blenderbot_small-90M", label: "BlenderBot Small (Lightweight)" },
    { value: "microsoft/DialoGPT-large", label: "DialoGPT Large (Advanced)" },
    { value: "facebook/blenderbot-1B-distill", label: "BlenderBot 1B (High Quality)" },
  ]

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      let assistantResponse = ""

      const response = await fetch(`https://api-inference.huggingface.co/models/${selectedModel}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: {
            past_user_inputs: messages
              .filter((m) => m.role === "user")
              .slice(-5)
              .map((m) => m.content),
            generated_responses: messages
              .filter((m) => m.role === "assistant")
              .slice(-5)
              .map((m) => m.content),
            text: userMessage.content,
          },
          parameters: {
            max_length: 1000,
            temperature: 0.7,
            do_sample: true,
            repetition_penalty: 1.1,
          },
        }),
      })

      if (!response.ok) {
        const fallbackModel =
          huggingFaceModels.find((m) => m.value !== selectedModel)?.value || "microsoft/DialoGPT-small"
        const fallbackResponse = await fetch(`https://api-inference.huggingface.co/models/${fallbackModel}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            inputs: userMessage.content,
            parameters: {
              max_length: 500,
              temperature: 0.7,
            },
          }),
        })

        if (!fallbackResponse.ok) {
          throw new Error("All Hugging Face models are currently unavailable")
        }

        const fallbackData = await fallbackResponse.json()
        assistantResponse =
          fallbackData[0]?.generated_text ||
          "I understand your message. Could you please rephrase or ask something else?"
      } else {
        const data = await response.json()

        if (data.generated_text) {
          assistantResponse = data.generated_text
        } else if (data.conversation && data.conversation.generated_responses) {
          assistantResponse = data.conversation.generated_responses[data.conversation.generated_responses.length - 1]
        } else if (Array.isArray(data) && data[0]?.generated_text) {
          assistantResponse = data[0].generated_text
        } else {
          assistantResponse = "I understand your message. Could you please rephrase or ask something else?"
        }
      }

      if (assistantResponse.includes(userMessage.content)) {
        assistantResponse = assistantResponse.replace(userMessage.content, "").trim()
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: assistantResponse || "I'm sorry, I couldn't generate a proper response. Please try again.",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Chat error:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `I'm experiencing some technical difficulties with the Hugging Face models. Please try again in a moment or try a different model.`,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const clearChat = () => {
    setMessages([
      {
        id: "1",
        role: "assistant",
        content: "Hello! I'm your AI assistant powered by Hugging Face. How can I help you today?",
        timestamp: new Date(),
      },
    ])
  }

  const features = [
    {
      icon: BrainIcon,
      title: "Intelligent Responses",
      description: "Advanced Hugging Face models that understand context and provide meaningful answers",
    },
    {
      icon: ClockIcon,
      title: "Real-time Chat",
      description: "Instant responses for seamless conversation flow",
    },
    {
      icon: ShieldIcon,
      title: "Privacy Focused",
      description: "Your conversations are secure and private by design",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="py-16 sm:py-24 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-emerald-50 dark:bg-emerald-950 rounded-full mb-6 sm:mb-8">
            <MessageSquareIcon className="h-8 w-8 sm:h-10 sm:w-10 text-emerald-600" />
          </div>
          <h1 className="text-3xl xs:text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-4 sm:mb-6 text-balance leading-tight">
            AI Chat <span className="text-accent">Assistance</span>
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground text-pretty max-w-xs xs:max-w-sm sm:max-w-3xl mx-auto mb-6 sm:mb-8 px-4 sm:px-0">
            Have intelligent conversations powered by Hugging Face's advanced AI models - completely free!
          </p>

          <div className="inline-flex items-center gap-2 bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 px-4 sm:px-6 py-2 sm:py-3 rounded-full text-base sm:text-lg font-medium">
            <SparklesIcon className="h-4 w-4 sm:h-5 sm:w-5" />
            Powered by Hugging Face - Always Free!
          </div>
        </div>
      </section>

      {/* Chat Interface */}
      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">Start Chatting</h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Choose from multiple Hugging Face models and start your conversation
            </p>
          </div>

          <Card className="mb-6 sm:mb-8">
            <CardHeader className="p-4 sm:p-6">
              <div className="flex flex-col gap-4">
                <div>
                  <CardTitle className="text-lg sm:text-xl">AI Chat Assistant</CardTitle>
                  <CardDescription className="text-sm sm:text-base">
                    Powered by Hugging Face's state-of-the-art language models
                  </CardDescription>
                </div>
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col xs:flex-row gap-2">
                    <Select value={selectedModel} onValueChange={setSelectedModel}>
                      <SelectTrigger className="w-full xs:w-[280px] text-sm sm:text-base">
                        <SelectValue placeholder="Select Hugging Face model" />
                      </SelectTrigger>
                      <SelectContent>
                        {huggingFaceModels.map((model) => (
                          <SelectItem key={model.value} value={model.value} className="text-sm">
                            {model.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      onClick={clearChat}
                      variant="outline"
                      size="sm"
                      className="w-full xs:w-auto text-sm bg-transparent border-border hover:bg-muted hover:text-foreground"
                    >
                      Clear Chat
                    </Button>
                  </div>

                  <div className="bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 rounded-lg p-3">
                    <p className="text-sm text-emerald-700 dark:text-emerald-300">
                      <strong>🤗 Hugging Face Powered:</strong> All models are completely free to use with no API keys
                      required. Experience the power of open-source AI!
                    </p>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4 sm:p-6 pt-0">
              <div className="space-y-4">
                {/* Chat Messages */}
                <ScrollArea className="h-[300px] sm:h-[400px] w-full border rounded-lg p-3 sm:p-4" ref={scrollAreaRef}>
                  <div className="space-y-3 sm:space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex gap-2 sm:gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`flex gap-2 sm:gap-3 max-w-[85%] sm:max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                        >
                          <div
                            className={`flex-shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center ${
                              message.role === "user" ? "bg-emerald-600 text-white" : "bg-muted text-foreground"
                            }`}
                          >
                            {message.role === "user" ? (
                              <UserIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                            ) : (
                              <BotIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                            )}
                          </div>
                          <div
                            className={`rounded-lg px-3 py-2 sm:px-4 sm:py-2 ${
                              message.role === "user" ? "bg-emerald-600 text-white" : "bg-muted text-foreground"
                            }`}
                          >
                            <p className="text-xs sm:text-sm leading-relaxed">{message.content}</p>
                            <p className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex gap-2 sm:gap-3 justify-start">
                        <div className="flex gap-2 sm:gap-3 max-w-[85%] sm:max-w-[80%]">
                          <div className="flex-shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center bg-muted text-foreground">
                            <BotIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                          </div>
                          <div className="rounded-lg px-3 py-2 sm:px-4 sm:py-2 bg-muted text-foreground">
                            <div className="flex items-center gap-2">
                              <LoaderIcon className="h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                              <span className="text-xs sm:text-sm">Thinking...</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                {/* Chat Input */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                    disabled={isLoading}
                    className="flex-1 text-sm sm:text-base"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={isLoading || !input.trim()}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 sm:px-4"
                    size="sm"
                  >
                    <SendIcon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 bg-muted/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4">
              Smart Conversation Features
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground px-4 sm:px-0">
              Experience the future of AI-powered communication with Hugging Face
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
            {features.map((feature) => {
              const IconComponent = feature.icon
              return (
                <Card key={feature.title} className="text-center border-border bg-card">
                  <CardHeader className="p-4 sm:p-6">
                    <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-muted rounded-lg mb-3 sm:mb-4 mx-auto">
                      <IconComponent className="h-5 w-5 sm:h-6 sm:w-6 text-emerald-600" />
                    </div>
                    <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6 pt-0">
                    <CardDescription className="text-muted-foreground text-sm sm:text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">Ready to Chat?</h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto px-4 sm:px-0">
            Start having intelligent conversations with our AI assistant powered by Hugging Face's cutting-edge models -
            completely free and no registration required!
          </p>
          <div className="flex flex-col xs:flex-row gap-3 sm:gap-4 justify-center px-4 sm:px-0">
            <Button
              asChild
              size="lg"
              className="bg-emerald-600 hover:bg-emerald-700 text-white w-full xs:w-auto text-sm sm:text-base"
            >
              <Link href="/tools" className="flex items-center justify-center gap-2">
                <ArrowLeftIcon className="h-4 w-4" />
                Explore Other Tools
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="bg-transparent border-border hover:bg-muted hover:text-foreground w-full xs:w-auto text-sm sm:text-base"
            >
              <Link href="/about">Learn More About QutbiStudio</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
