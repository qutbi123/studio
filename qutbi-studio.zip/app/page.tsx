import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AdBanner } from "@/components/ad-banner"
import { ImageIcon, MicIcon, MessageSquareIcon, VideoIcon, ArrowRightIcon, SparklesIcon } from "lucide-react"
import Image from "next/image"

export default function HomePage() {
  const aiTools = [
    {
      title: "AI Image Generator",
      description: "Create stunning visuals with advanced AI technology",
      icon: ImageIcon,
      href: "/tools/image",
      color: "text-blue-600",
    },
    {
      title: "AI Voice Generator",
      description: "Transform text into natural-sounding speech",
      icon: MicIcon,
      href: "/tools/voice",
      color: "text-green-600",
    },
    {
      title: "AI Chat Assistance",
      description: "Get intelligent responses and conversations",
      icon: MessageSquareIcon,
      href: "/tools/chat",
      color: "text-purple-600",
    },
    {
      title: "AI Video Maker",
      description: "Generate and edit videos with AI assistance",
      icon: VideoIcon,
      href: "/tools/video",
      color: "text-red-600",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
          <div className="text-center">
            {/* Hero Badge */}
            <div className="inline-flex items-center gap-2 bg-accent/20 text-accent-foreground px-3 py-1.5 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-medium mb-6 sm:mb-8">
              <SparklesIcon className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Powered by Advanced AI Technology</span>
              <span className="xs:hidden">AI Powered</span>
            </div>

            {/* Hero Title */}
            <h1 className="text-3xl xs:text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-primary mb-4 sm:mb-6 text-balance leading-tight">
              Welcome to <span className="text-accent">QutbiStudio</span>
              <br className="hidden xs:block" />
              <span className="xs:hidden"> </span>Your AI Powerhouse
            </h1>

            {/* Hero Description */}
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-muted-foreground mb-8 sm:mb-12 max-w-xs xs:max-w-sm sm:max-w-2xl lg:max-w-3xl mx-auto text-pretty px-4 sm:px-0">
              Unleash the power of artificial intelligence with our comprehensive suite of AI tools. Create,
              communicate, and innovate like never before.
            </p>

            {/* Hero CTA Buttons */}
            <div className="flex flex-col xs:flex-row gap-3 sm:gap-4 justify-center items-center mb-12 sm:mb-16 px-4 sm:px-0">
              <Button
                asChild
                size="lg"
                className="bg-accent hover:bg-accent/90 text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-6 w-full xs:w-auto"
              >
                <Link href="/tools" className="flex items-center justify-center gap-2">
                  Explore AI Tools
                  <ArrowRightIcon className="h-4 w-4 sm:h-5 sm:w-5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-6 bg-transparent w-full xs:w-auto"
              >
                <Link href="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-4 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AdBanner size="horizontal" className="mx-auto" />
        </div>
      </section>

      {/* Founder's Message Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-accent/20 bg-gradient-to-br from-card to-muted/30">
            <CardHeader className="text-center pb-6">
              <div className="flex flex-col items-center gap-6">
                <div className="relative">
                  <Image
                    src="/images/founder.jpg"
                    alt="Qutbi Shahzada Muhammad Usman Ali Awan Alvi - Founder & CEO"
                    width={120}
                    height={120}
                    className="rounded-full object-cover border-4 border-accent/20"
                  />
                  <div className="absolute -bottom-2 -right-2 bg-accent text-accent-foreground rounded-full p-2">
                    <SparklesIcon className="h-4 w-4" />
                  </div>
                </div>
                <div>
                  <CardTitle className="text-2xl sm:text-3xl font-bold text-primary mb-2">Founder's Message</CardTitle>
                  <p className="text-accent font-medium">Qutbi Shahzada Muhammad Usman Ali Awan Alvi</p>
                  <p className="text-sm text-muted-foreground">Founder & CEO</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="px-6 sm:px-8 pb-8">
              <div className="prose prose-gray dark:prose-invert max-w-none">
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-4">Dear Visitors,</p>
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-4">
                  It gives me great pleasure to announce that through our company,{" "}
                  <strong className="text-accent">Qutbi Technologies & Innovative Solution</strong>, we have launched{" "}
                  <strong className="text-primary">Kashmir First AI studio</strong>.
                </p>
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-4">
                  This platform is specially designed to bring you advanced AI tools all in one place — including AI
                  Chat Assistance, AI Image Generator, AI Voice Generator, and AI Video Maker.
                </p>
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed mb-4">
                  Our mission is to provide you with the best experience and innovative solutions that make your digital
                  journey easier and more powerful.
                </p>
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                  We look forward to your valuable feedback and truly hope you will like our project.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* AI Tools Preview Section */}
      <section className="py-16 sm:py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-3 sm:mb-4 px-4 sm:px-0">
              Powerful AI Tools at Your Fingertips
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto px-4 sm:px-0">
              Discover our collection of cutting-edge AI tools designed to enhance your creativity and productivity.
            </p>
          </div>

          <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {aiTools.map((tool) => {
              const IconComponent = tool.icon
              return (
                <Card
                  key={tool.title}
                  className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border bg-card"
                >
                  <CardHeader className="text-center pb-3 sm:pb-4 p-4 sm:p-6">
                    <div
                      className={`inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-muted mb-3 sm:mb-4 mx-auto group-hover:scale-110 transition-transform duration-300`}
                    >
                      <IconComponent className={`h-6 w-6 sm:h-8 sm:w-8 ${tool.color}`} />
                    </div>
                    <CardTitle className="text-lg sm:text-xl font-semibold text-card-foreground">
                      {tool.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center p-4 sm:p-6 pt-0">
                    <CardDescription className="text-muted-foreground mb-4 sm:mb-6 text-sm sm:text-base">
                      {tool.description}
                    </CardDescription>
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="w-full group-hover:bg-accent group-hover:text-accent-foreground transition-colors bg-transparent"
                    >
                      <Link href={tool.href} className="flex items-center justify-center gap-2">
                        Try Now
                        <ArrowRightIcon className="h-3 w-3 sm:h-4 sm:w-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="mt-12 sm:mt-16">
            <AdBanner size="horizontal" className="mx-auto" />
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-16 sm:py-24 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl xs:text-3xl sm:text-4xl font-bold text-primary mb-4 sm:mb-6">
            Ready to Transform Your Workflow?
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-xs xs:max-w-sm sm:max-w-2xl mx-auto">
            Join thousands of creators and professionals who are already using QutbiStudio to enhance their projects
            with AI.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-accent hover:bg-accent/90 text-base sm:text-lg px-6 sm:px-8 py-3 sm:py-6 w-full xs:w-auto"
          >
            <Link href="/tools" className="flex items-center justify-center gap-2">
              Get Started Today
              <ArrowRightIcon className="h-4 w-4 sm:h-5 sm:w-5" />
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
