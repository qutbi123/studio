import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { AdBanner } from "@/components/ad-banner"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Header Section */}
      <section className="py-16 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-primary mb-4">Privacy Policy</h1>
          <p className="text-lg text-muted-foreground">Last updated: January 2025</p>
        </div>
      </section>

      <AdBanner type="horizontal" title="Advertise Here" description="Reach privacy-conscious users" className="my-8" />
      {/* ADD AD SCRIPT HERE: Place your ad network script for top banner placement */}

      {/* Privacy Policy Content */}
      <section className="py-16 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-border bg-card">
            <CardContent className="p-8 space-y-8">
              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Introduction</h2>
                <p className="text-muted-foreground leading-relaxed">
                  At QutbiStudio, we are committed to protecting your privacy and ensuring the security of your personal
                  information. This Privacy Policy explains how we collect, use, disclose, and safeguard your
                  information when you use our AI-powered tools and services.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Information We Collect</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium text-card-foreground mb-2">Personal Information</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      We may collect personal information that you voluntarily provide, including but not limited to
                      your name, email address, and account preferences when you create an account or contact us.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-card-foreground mb-2">Usage Data</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      We automatically collect information about how you interact with our services, including IP
                      addresses, browser type, device information, and usage patterns to improve our services.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-card-foreground mb-2">AI Tool Interactions</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      When you use our AI tools, we may collect and process the content you input (text, images, etc.)
                      to provide the requested services and improve our AI models.
                    </p>
                  </div>
                </div>
              </div>

              <AdBanner type="square" title="Your Ad Here" description="Mid-content placement" className="my-6" />
              {/* ADD AD SCRIPT HERE: Place your mid-content ad script here for engaged readers */}

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">How We Use Your Information</h2>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>To provide, maintain, and improve our AI tools and services</li>
                  <li>To process your requests and respond to your inquiries</li>
                  <li>To personalize your experience and provide relevant content</li>
                  <li>To analyze usage patterns and optimize our platform performance</li>
                  <li>To communicate with you about updates, security alerts, and support</li>
                  <li>To comply with legal obligations and protect our rights</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Information Sharing and Disclosure</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  We do not sell, trade, or otherwise transfer your personal information to third parties without your
                  consent, except in the following circumstances:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>With service providers who assist us in operating our platform</li>
                  <li>When required by law or to protect our rights and safety</li>
                  <li>In connection with a business transfer or acquisition</li>
                  <li>With your explicit consent for specific purposes</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Data Security</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We implement appropriate technical and organizational security measures to protect your personal
                  information against unauthorized access, alteration, disclosure, or destruction. However, no method of
                  transmission over the internet is 100% secure, and we cannot guarantee absolute security.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Cookies and Tracking Technologies</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We use cookies and similar tracking technologies to enhance your experience, analyze usage patterns,
                  and provide personalized content. You can control cookie preferences through your browser settings,
                  though some features may not function properly if cookies are disabled.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Your Rights and Choices</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Depending on your location, you may have the following rights regarding your personal information:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Access and review your personal information</li>
                  <li>Correct inaccurate or incomplete information</li>
                  <li>Delete your personal information</li>
                  <li>Restrict or object to certain processing activities</li>
                  <li>Data portability for information you provided</li>
                  <li>Withdraw consent where processing is based on consent</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Children's Privacy</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Our services are not intended for children under 13 years of age. We do not knowingly collect personal
                  information from children under 13. If we become aware that we have collected personal information
                  from a child under 13, we will take steps to delete such information.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">International Data Transfers</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Your information may be transferred to and processed in countries other than your own. We ensure that
                  such transfers comply with applicable data protection laws and implement appropriate safeguards to
                  protect your information.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Changes to This Privacy Policy</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We may update this Privacy Policy from time to time to reflect changes in our practices or applicable
                  laws. We will notify you of any material changes by posting the updated policy on our website and
                  updating the "Last updated" date.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-card-foreground mb-4">Contact Us</h2>
                <p className="text-muted-foreground leading-relaxed">
                  If you have any questions about this Privacy Policy or our privacy practices, please contact us at:
                </p>
                <div className="mt-4 p-4 bg-muted rounded-lg">
                  <p className="text-card-foreground font-medium">QutbiStudio Privacy Team</p>
                  <p className="text-muted-foreground">Email: privacy@qutbistudio.com</p>
                  <p className="text-muted-foreground">Address: [Your Business Address]</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <AdBanner
        type="horizontal"
        title="Premium Ad Space"
        description="Bottom page placement for maximum visibility"
        className="my-8"
      />
      {/* ADD AD SCRIPT HERE: Place your bottom banner ad script here */}

      <Footer />
    </div>
  )
}
